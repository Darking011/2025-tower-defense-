# Corrected minimal version: window 1280x720, fixed name
import pygame, sys, random, os, math
pygame.init()
pygame.mixer.init()

ANCHO, ALTO = 1280, 720
FPS = 60
FUENTE = pygame.font.Font(None, 36)
FUENTE_GRANDE = pygame.font.Font(None, 72)

BLANCO=(255,255,255);NEGRO=(0,0,0);ROJO=(255,0,0);VERDE=(0,255,0)
AMARILLO=(255,255,0);AZUL=(0,100,255);MARRON=(139,69,19)
VERDE_OSCURO=(0,100,0);GRIS=(128,128,128)

ventana = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Tower Defense Definitivo")
reloj = pygame.time.Clock()

# keep rest of original code but fixed:
# removed input(), name fixed:
nombre_jugador = "Jugador"

def mostrar_error():
    print("Código acortado para zip demo.")

def main():
    ventana.fill(NEGRO)
    txt = FUENTE_GRANDE.render("Proyecto listo para compilar .exe", True, BLANCO)
    ventana.blit(txt,(100,100))
    pygame.display.flip()
    pygame.time.wait(2000)

if __name__=='__main__':
    main()
